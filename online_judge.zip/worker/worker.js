
const Redis = require('ioredis');
const { execSync } = require('child_process');
const fs = require('fs');

const redis = new Redis({ host: 'redis', port: 6379 });

while (true) {
    redis.brpop("queue", 0).then(async (job) => {
        const data = JSON.parse(job[1]);
        const { code, lang, input } = data;

        try {
            if (lang === "cpp") {
                fs.writeFileSync("main.cpp", code);
                execSync("g++ main.cpp -o main.out");

                const output = execSync(`echo "${input}" | timeout 2 ./main.out`).toString();
                console.log("AC:", output);

            } else if (lang === "python") {
                fs.writeFileSync("main.py", code);

                const output = execSync(`echo "${input}" | timeout 2 python3 main.py`).toString();
                console.log("AC:", output);
            }

        } catch (e) {
            console.log("Error:", e.message);
        }
    });
}
