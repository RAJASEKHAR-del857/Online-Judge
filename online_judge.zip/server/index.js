
const express = require('express');
const Redis = require('ioredis');
const app = express();
app.use(express.json());

const redis = new Redis({ host: 'redis', port: 6379 });

app.post('/submit', async (req, res) => {
    const job = req.body;
    await redis.lpush("queue", JSON.stringify(job));
    res.json({ status: "submitted" });
});

app.listen(3000, () => console.log("Server running"));
