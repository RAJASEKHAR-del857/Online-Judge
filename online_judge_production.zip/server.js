import express from "express";
import { Queue } from "bullmq";
import IORedis from "ioredis";

const app = express();
app.use(express.json());

const connection = new IORedis();
const submissionQueue = new Queue("submissions", { connection });

app.post("/submit", async (req, res) => {
    const { code, language, input } = req.body;

    const job = await submissionQueue.add("execute", {
        code,
        language,
        input
    });

    res.json({ jobId: job.id });
});

app.listen(3000, () => console.log("Server running"));
