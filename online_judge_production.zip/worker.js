import { Worker } from "bullmq";
import { exec } from "child_process";
import fs from "fs";

const worker = new Worker("submissions", async job => {
    const { code, language } = job.data;

    const filePath = `/tmp/code.${language}`;
    fs.writeFileSync(filePath, code);

    const command = `
    docker run --rm --memory=100m --cpus=0.5 --network=none \
    -v ${filePath}:/app/code.${language} judge-image \
    sh -c "compile_and_run.sh ${language}"
    `;

    return new Promise((resolve) => {
        exec(command, { timeout: 2000 }, (err, stdout, stderr) => {
            if (err) return resolve({ status: "Error", error: stderr });
            resolve({ status: "Success", output: stdout });
        });
    });
});
