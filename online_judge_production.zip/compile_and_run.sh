#!/bin/bash

lang=$1

if [ "$lang" = "cpp" ]; then
    g++ code.cpp -o code.out
    ./code.out
elif [ "$lang" = "py" ]; then
    python3 code.py
elif [ "$lang" = "java" ]; then
    javac code.java
    java Main
fi
