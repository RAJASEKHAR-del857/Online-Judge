# Online Judge System (Production Ready)

## Features
- Docker-based secure execution
- Redis + BullMQ queue
- Worker-based scalable architecture
- Multi-language support (C++, Python, Java)

## Setup

### 1. Install dependencies
npm install

### 2. Run Redis
docker run -d -p 6379:6379 redis

### 3. Build Docker image
docker build -t judge-image .

### 4. Start server
node server.js

### 5. Start worker
node worker.js

## API

POST /submit
{
  "code": "...",
  "language": "cpp"
}

Returns:
{
  "jobId": "..."
}
